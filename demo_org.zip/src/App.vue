<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>-->
    <header class="header" style="height: 14vh;">
      <GlobalHeader />
    </header>
    <router-view />
    <GlobalFooter />
  </div>
</template>

<script>
import GlobalHeader from "@/components/GlobalHeader.vue";
import GlobalFooter from "@/components/GlobalFooter.vue";

export default {
  components: {
    GlobalHeader,
    GlobalFooter
  }
};
</script>
