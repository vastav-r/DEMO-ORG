<template>
  <div class="site-header wrapper" role="banner">
    <div class="grid--full grid--table container">
      <div class="row">
        <!-- <div class="grid__item large--hide large--one-sixth one-quarter">
        <div class="site-nav--open site-nav--mobile site-nav--init">
          <button
            type="button"
            class="icon-fallback-text site-nav__link site-nav__link--burger js-drawer-open-button-left"
            aria-controls="NavDrawer"
            aria-expanded="false"
          >
            <span class="burger-icon burger-icon--top"></span>
            <span class="burger-icon burger-icon--mid"></span>
            <span class="burger-icon burger-icon--bottom"></span>
            <span class="fallback-text">Site navigation</span>
          </button>
        </div>
        </div>-->
        <div class="grid__item large--one-third medium-down--one-half col-4">
          <div class="h1 site-header__logo large--left">
            <a to="/" itemprop="url" class="site-header__logo-link">
              <img src alt="Hux Demo Org logo" style="display: none;" />
              <h3>Hux Demo Org</h3>
            </a>
          </div>
        </div>
        <nav
          class="grid__item large--two-thirds large--text-right medium-down--hide"
          role="navigation"
        >
          <!-- begin site-nav -->
          <ul class="site-nav site-nav--init" id="AccessibleNav">
            <li
              class="site-nav__item site-nav--has-dropdown"
              aria-haspopup="true"
              data-meganav-type="parent"
              @mouseover="hover=true"
              @mouseleave="hover=false"
              :class="{ nav_hover: hover }"
            >
              <a
                href="/collections"
                class="site-nav__link"
                data-meganav-type="parent"
                aria-controls="MenuParent-1"
                aria-expanded="false"
              >
                Shop
                <span class="icon icon-arrow-down" aria-hidden="true">
                  <font-awesome-icon icon="sort-down" />
                </span>
              </a>
              <ul id="MenuParent-1" class="site-nav__dropdown" data-meganav-dropdown v-if="hover">
                <li>
                  <a
                    href="/collections/baking"
                    class="site-nav__dropdown-link"
                    data-meganav-type="child"
                    tabindex="-1"
                  >Lorem</a>
                </li>

                <li>
                  <a
                    href="/collections/decorating"
                    class="site-nav__dropdown-link"
                    data-meganav-type="child"
                    tabindex="-1"
                  >Ipsum</a>
                </li>
              </ul>
            </li>

            <li class="site-nav__item site-nav--active">
              <a
                href="/pages/about-us"
                class="site-nav__link"
                data-meganav-type="child"
                aria-current="page"
              >About Us</a>
            </li>

            <li class="site-nav__item">
              <a href="/blogs/sweet-blog" class="site-nav__link" data-meganav-type="child">Blog</a>
            </li>

            <li class="site-nav__item">
              <a
                href="/pages/contact-us"
                class="site-nav__link"
                data-meganav-type="child"
              >Contact Us</a>
            </li>

            <li class="site-nav__item site-nav__item--compressed">
              <a
                href="/search"
                class="site-nav__link site-nav__link--icon js-toggle-search-modal"
                data-mfp-src="#SearchModal"
              >
                <span class="icon-fallback-text">
                  <!-- <span class="icon icon-search" aria-hidden="true">
                    <font-awesome-icon icon="shopping-cart" />
                  </span>
                  <span class="fallback-text">Search</span>-->
                  <font-awesome-icon icon="search" size="lg" />
                </span>
              </a>
            </li>

            <li class="site-nav__item site-nav__item--compressed">
              <a
                href="/cart"
                class="site-nav__link site-nav__link--icon cart-link js-drawer-open-button-right"
                aria-controls="CartDrawer"
                aria-expanded="false"
              >
                <span class="icon-fallback-text">
                  <!-- <span class="icon icon-cart" aria-hidden="true"></span>
                  <span class="fallback-text">Cart</span>-->
                  <font-awesome-icon icon="shopping-cart" size="lg" />
                </span>
                <span class="cart-link__bubble cart-link__bubble--visible"></span>
              </a>
            </li>
          </ul>
          <!-- //site-nav -->
        </nav>
        <div class="grid__item large--hide one-quarter">
          <div class="site-nav--mobile text-right">
            <a
              href="/cart"
              class="site-nav__link cart-link js-drawer-open-button-right"
              aria-controls="CartDrawer"
              aria-expanded="false"
            >
              <span class="icon-fallback-text">
                <span class="icon icon-cart" aria-hidden="true"></span>
                <span class="fallback-text">Cart</span>
              </span>
              <span class="cart-link__bubble cart-link__bubble--visible"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { library } from "@fortawesome/fontawesome-svg-core";
import { faSortDown } from "@fortawesome/free-solid-svg-icons";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { faSearch } from "@fortawesome/free-solid-svg-icons";

library.add(faSortDown);
library.add(faShoppingCart);
library.add(faSearch);

export default {
  name: "GlobalHeader",
  data() {
    return {
      hover: false
    };
  }
};
</script>