<template>
  <div class="homeContent">
    <div class="hero-text-content">
      <p class="hero__subtitle">Lorem ipsum dolor sit.</p>

      <h2 class="hero__title">Lorem, ipsum dolor.</h2>
      <router-link to="/allproducts">
        <button class="btn shopNowButton">Shop Now</button>
      </router-link>
    </div>
    <div class="mainContent">
      <div class="sections">
        <div class="descSection">
          <div class="rich-text wrapper">
            <div class="grid">
              <div
                class="grid__item text-center large--two-thirds medium--two-thirds push--large--one-sixth push--medium--one-sixth"
              >
                <div class="rte rich-text__text--medium">
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit ducimus cumque illo! Quidem eos voluptatem, doloremque exercitationem labore aliquam commodi aperiam unde non incidunt, perspiciatis velit in eligendi, voluptatum mollitia?</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="featuredCategories container">
          <div class="section-header text-center">
            <h2 class="h1 section-header__title">Lorem, ipsum.</h2>
            <hr class="hr--small" style="border-top: solid #5dd2b4;" />
          </div>
          <div class="row collage-row">
            <div class="col-8 large">
              <img class="largeProductImage" src="https://dummyimage.com/700x450/000/fff" />
              <div class="productNameContainer">
                <router-link to="/products/gem-sugar" class="grid-product__meta">
                  <span class="productName">Lorem, ipsum dolor.</span>
                  <span class="long-dash">—</span>
                  <span class="grid-product__price">
                    <span class="visually-hidden">Regular price</span>
                    $7
                  </span>
                </router-link>
              </div>
            </div>
            <div class="col-4 small">
              <div class="smallHalf">
                <img class="smallProductImage" src="https://dummyimage.com/350x200/000/fff" />
                <div class="productNameContainer">
                  <router-link to="/products/gem-sugar" class="grid-product__meta">
                    <span class="productName">Lorem, ipsum dolor.</span>
                    <span class="long-dash">—</span>
                    <span class="grid-product__price">
                      <span class="visually-hidden">Regular price</span>
                      $7
                    </span>
                  </router-link>
                </div>
              </div>
              <div class="smallHalf">
                <img class="smallProductImage" src="https://dummyimage.com/350x200/000/fff" />
                <div class="productNameContainer">
                  <router-link to="/products/gem-sugar" class="grid-product__meta">
                    <span class="productName">Lorem, ipsum dolor.</span>
                    <span class="long-dash">—</span>
                    <span class="grid-product__price">
                      <span class="visually-hidden">Regular price</span>
                      $7
                    </span>
                  </router-link>
                </div>
              </div>
            </div>
          </div>
          <!-- <div class="grid grid-collage">
            <div class="grid__item collage-grid__row">
              <div class="grid">
                <div
                  class="grid__item grid-product grid__item--large one-whole medium--two-thirds large--two-thirds"
                >
                  <div class="grid-product__wrapper">
                    <div class="grid-product__image-wrapper">
                      <a class="grid-product__image-link" href="grid-product__image-link" />
                      <div class="product--wrapper">
                        <div style="padding-top: 100%;">
                          <img class="product--image" src="https://dummyimage.com/740x740/000/fff" />
                          <a href="/products/gem-sugar" class="grid-product__meta">
                            <span class="grid-product__title">Gem Sugar</span>
                            <span class="grid-product__price-wrap">
                              <span class="long-dash">—</span>
                              <span class="grid-product__price">
                                <span class="visually-hidden">Regular price</span>

                                $7
                              </span>
                            </span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>-->
        </div>
      </div>
    </div>
    <div id="shopify-section-newsletter" class="shopify-section index-newsletter-section">
      <div class="newsletter" data-section-id="newsletter" data-section-type="newsletter-section">
        <div class="wrapper">
          <div class="section-header text-center">
            <h2 class="h1 section-header__title">Subscribe to our newsletter</h2>
          </div>

          <div class="section-subheading rte text-center">
            <p>Sign up to stay in the loop. Receive updates, access to exclusive deals, and more.</p>
            <hr class="hr--small" />
          </div>

          <form
            method="post"
            action="/contact#contact_form"
            id="contact_form"
            accept-charset="UTF-8"
            class="contact-form"
          >
            <input type="hidden" name="form_type" value="customer" />
            <input type="hidden" name="utf8" value="✓" />

            <label for="Email" class="newsletter__label hidden-label">Sign up to our mailing list</label>
            <input type="hidden" name="contact[tags]" value="newsletter" />
            <div class="newsletter--form">
              <div class="input-group">
                <input
                  type="email"
                  value
                  placeholder="Your email"
                  name="contact[email]"
                  id="Email"
                  class="input-group-field newsletter__input"
                  autocorrect="off"
                  autocapitalize="off"
                />
                <span class="input-group-btn">
                  <button
                    id="Subscribe"
                    type="submit"
                    class="btn newsletter__submit"
                    aria-label="Subscribe"
                  >
                    <span class="newsletter__submit-text--large">Subscribe</span>
                    <span class="newsletter__submit-text--small">
                      <span class="icon icon-arrow-right" aria-hidden="true"></span>
                    </span>
                  </button>
                </span>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
    <hr class="hr--large" />
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from "@/components/HelloWorld.vue";

export default {
  name: "home",
  components: {}
};
</script>
