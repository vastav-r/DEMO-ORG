<template>
  <div id="PageContainer" class="page-container">
    <main class="main-content" role="main">
      <div class="wrapper">
        <div id="shopify-section-product-template" class="shopify-section">
          <div itemscope itemtype="http://schema.org/Product" id="ProductSection--product-template">
            <div class="grid product-single">
              <div class="grid__item large--seven-twelfths medium--seven-twelfths text-center">
                <div class="product-single__photos">
                  <div class="product-single__photo--flex-wrapper">
                    <div class="product-single__photo--flex">
                      <div
                        id="ProductImageWrapper-23152729538"
                        class="product-single__photo--container"
                      >
                        <div class="product-single__photo-wrapper" style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product-single__photo"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-single__photo--flex-wrapper">
                    <div class="product-single__photo--flex">
                      <div
                        id="ProductImageWrapper-23152729538"
                        class="product-single__photo--container"
                      >
                        <div class="product-single__photo-wrapper" style="padding-top:100.0%;">
                          <!-- <img
                            src="../assets/Commerce Site Photos/Hoodie_A3.jpg"
                            class="product-single__photo"
                          />-->
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product-single__photo"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-single__photo--flex-wrapper">
                    <div class="product-single__photo--flex">
                      <div
                        id="ProductImageWrapper-23152729538"
                        class="product-single__photo--container"
                      >
                        <div class="product-single__photo-wrapper" style="padding-top:100.0%;">
                          <!-- <img
                            src="../assets/Commerce Site Photos/T Shirt_A3.jpg"
                            class="product-single__photo"
                          />-->
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product-single__photo"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                class="grid__item product-single__meta--wrapper medium--five-twelfths large--five-twelfths"
              >
                <div class="product-single__meta">
                  <h1 class="product-single__title" itemprop="name" id="productName">Canvas Shoes</h1>
                  <div itemprop="offers" itemscope itemtype="http://schema.org/Offer">
                    <div data-price-container>
                      <span id="PriceA11y" class="visually-hidden">Regular price</span>
                      <span class="product-single__price--wrapper hide" aria-hidden="true">
                        <span id="ComparePrice" class="product-single__price--compare-at"></span>
                      </span>
                      <span
                        id="ComparePriceA11y"
                        class="visually-hidden"
                        aria-hidden="true"
                      >Sale price</span>
                      <span
                        id="ProductPrice"
                        class="product-single__price"
                        itemprop="price"
                        content="7.0"
                      >$17.00</span>
                    </div>
                    <hr class="hr--small" />
                    <form
                      method="post"
                      action="/cart/add"
                      id="AddToCartForm--product-template"
                      accept-charset="UTF-8"
                      class="product-single__form"
                    >
                      <input type="hidden" name="form_type" value="product" />
                      <input type="hidden" name="utf8" value="✓" />
                      <div class="radio-wrapper js product-form__item">
                        <label class="single-option-radio__label" for="ProductSelect-option-0">Color</label>
                        <fieldset
                          class="single-option-radio"
                          name="color"
                          id="ProductSelect-option-0"
                        >
                          <input
                            type="radio"
                            checked="checked"
                            value="Aquamarine"
                            data-index="option1"
                            name="color"
                            class="single-option-selector__radio"
                            id="ProductSelect-option-color-Aquamarine"
                          />
                          <label for="ProductSelect-option-color-Aquamarine">Magenta</label>
                          <input
                            type="radio"
                            value="Rose"
                            data-index="option1"
                            name="color"
                            class="single-option-selector__radio"
                            id="ProductSelect-option-color-Rose"
                          />
                          <label for="ProductSelect-option-color-Rose">Turquoise</label>
                          <input
                            type="radio"
                            value="Emerald"
                            data-index="option1"
                            name="color"
                            class="single-option-selector__radio"
                            id="ProductSelect-option-color-Emerald"
                          />
                          <label for="ProductSelect-option-color-Emerald">Allenin</label>
                          <input
                            type="radio"
                            value="Amethyst"
                            data-index="option1"
                            name="color"
                            class="single-option-selector__radio"
                            id="ProductSelect-option-color-Amethyst"
                          />
                          <label for="ProductSelect-option-color-Amethyst">Blue</label>
                        </fieldset>
                      </div>
                      <select name="id" id="ProductSelect" class="product-single__variants no-js">
                        <option selected="selected" data-sku value="35459193794">Magenta - $7.00 CAD</option>
                        <option data-sku value="35459193602">Turquoise - $7.00 CAD</option>
                        <option data-sku value="35459193666">Auburn - $7.00 CAD</option>
                        <option data-sku value="35459192898">Allenin - $7.00 CAD</option>
                      </select>
                      <div class="product-single__add-to-cart">
                        <button
                          type="submit"
                          name="add"
                          id="AddToCart--product-template"
                          class="btn btn--add-to-cart btn--secondary-accent"
                        >
                          <span class="btn__text">Add to Cart</span>
                        </button>
                        <div data-shopify="payment-button" class="shopify-payment-button">
                          <div>
                            <button
                              type="button"
                              class="shopify-payment-button__button shopify-payment-button__button--unbranded _2ogcW-Q9I-rgsSkNbRiJzA _2EiMjnumZ6FVtlC7RViKtj _2-dUletcCZ2ZL1aaH0GXxT"
                              data-testid="Checkout-button"
                              @click="saveProductInfo"
                            >Buy it now</button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="product-single__description rte" itemprop="description">
                    <div>
                      <meta charset="utf-8" />
                      <h6>
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.&nbsp;
                        <a
                          href
                          target="_blank"
                          title="Layer Cake Shop online store"
                          rel="noopener noreferrer"
                          class="text-link"
                        >Lorem ipsum dolor sit amet.</a>
                      </h6>
                      <p>
                        <span
                          style="font-weight: 400;"
                        >Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima in omnis iure minus doloribus dolores totam, est quod nobis at.</span>
                      </p>
                      <ul></ul>
                    </div>
                    <ul>
                      <li>
                        <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, dolorem.</span>
                      </li>
                      <li>
                        <span>Lorem ipsum dolor sit amet consectetur.</span>
                      </li>
                      <li>4 ounces</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <hr class="hr--large" />
  </div>
</template>

<script>
export default {
  name: "productdescription",
  methods: {
    saveProductInfo() {
      var productName = document.getElementById("productName").textContent;
      var productPrice = document.getElementById("ProductPrice").textContent;
      productPrice = productPrice.replace("$", "");
      // var obj = {
      //   name: productName,
      //   price: productPrice
      // };
      localStorage.setItem("productName", productName);
      localStorage.setItem("productPrice", productPrice);
      //console.log(obj);
      this.$router.push({ name: "checkout" });
    }
  }
};
</script>

<style>
</style>