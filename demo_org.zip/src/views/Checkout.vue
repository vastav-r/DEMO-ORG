<template>
  <main id="pageContainer" class="page-container">
    <main class="main-content" role="main">
      <div class="wrapper">
        <div id="shopify-section-collection-template" class="shopify-section">
          <div id="collectionSection">
            <header class="section-header text-center">
              <h1>Checkout</h1>
              <hr class="hr--small" />
            </header>
            <!-- <div class="grid-uniform">
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <router-link
                      class="grid-product__image-link"
                      to="/products/sampleproduct"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </router-link>
                    <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>
                  </div>
                  <router-link to="/products/sampleproduct" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </router-link>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas2.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas3.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__on-sale">
                      <p>
                        Save
                        <br />$1
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third is-sold-out">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas2.jpg"
                            class="product--image"
                          />
                          <img src="https://dummyimage.com/370x370/000/fff" class="product--image" />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas3.jpg"
                            class="product--image"
                          />
                          <img src="https://dummyimage.com/370x370/000/fff" class="product--image" />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product--image"
                          />
                          <img src="https://dummyimage.com/370x370/000/fff" class="product--image" />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__on-sale">
                      <p>
                        Save
                        <br />$1
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
            </div>-->
            <h2>Order summary</h2>
            <!-- <div class="order-summary__sections">
              <div class="order-summary__section order-summary__section--product-list">
                <div class="order-summary__section__content">
                  <table class="product-table">
                    <thead class="product-table__header">
                      <tr>
                        <th>
                          <span class="table-header">Product image</span>
                        </th>
                        <th>
                          <span class="table-header">Description</span>
                        </th>
                        <th>
                          <span class="table-header">Quantity</span>
                        </th>
                        <th>
                          <span class="table-header">Price</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody data-order-summary-section="line-items">
                      <tr
                        class="product"
                        data-product-id="9588963074"
                        data-variant-id="35464549186"
                        data-product-type="Candles"
                        data-customer-ready-visible
                      >
                        <td class="product__image">
                          <div class="product-thumbnail">
                            <div class="product-thumbnail__wrapper">
                              <img
                                alt="Light Pink Candy Melts"
                                class="product-thumbnail__image"
                                src="//cdn.shopify.com/s/files/1/1915/7471/products/Candy-melts_0000_Light-Pink-Candy-Melts_small.png?287"
                              />
                            </div>
                            <span class="product-thumbnail__quantity" aria-hidden="true">1</span>
                          </div>
                        </td>
                        <th class="product__description" scope="row">
                          <span
                            class="product__description__name order-summary__emphasis"
                          >Candy Melt</span>
                          <span
                            class="product__description__variant order-summary__small-text"
                          >Light Pink</span>
                        </th>
                        <td class="product__quantity visually-hidden">1</td>
                        <td class="product__price">
                          <span class="order-summary__emphasis">$5.00</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <div class="order-summary__scroll-indicator" aria-hidden="true" tabindex="-1">
                    Scroll for more items
                    <svg
                      aria-hidden="true"
                      focusable="false"
                      class="icon-svg icon-svg--size-12"
                    >
                      <use xlink:href="#down-arrow" />
                    </svg>
                  </div>
                </div>
              </div>

              <div
                class="order-summary__section order-summary__section--total-lines"
                data-order-summary-section="payment-lines"
              >
                <table class="total-line-table">
                  <caption class="visually-hidden">Cost summary</caption>
                  <thead>
                    <tr>
                      <th scope="col">
                        <span class="visually-hidden">Description</span>
                      </th>
                      <th scope="col">
                        <span class="visually-hidden">Price</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody class="total-line-table__tbody">
                    <tr class="total-line total-line--subtotal">
                      <th class="total-line__name" scope="row">Subtotal</th>
                      <td class="total-line__price">
                        <span
                          class="order-summary__emphasis"
                          data-checkout-subtotal-price-target="500"
                        >$5.00</span>
                      </td>
                    </tr>

                    <tr class="total-line total-line--shipping">
                      <th class="total-line__name" scope="row">
                        <span>Shipping</span>
                      </th>
                      <td class="total-line__price">
                        <span
                          class="order-summary__emphasis"
                          data-checkout-total-shipping-target="956"
                        >$9.56</span>
                      </td>
                    </tr>

                    <tr class="total-line total-line--taxes hidden" data-checkout-taxes>
                      <th class="total-line__name" scope="row">Taxes (estimated)</th>
                      <td class="total-line__price">
                        <span
                          class="order-summary__emphasis"
                          data-checkout-total-taxes-target="0"
                        >$0.00</span>
                      </td>
                    </tr>
                  </tbody>
                  <tfoot class="total-line-table__footer">
                    <tr class="total-line">
                      <th class="total-line__name payment-due-label" scope="row">
                        <span class="payment-due-label__total">Total</span>
                      </th>
                      <td class="total-line__price payment-due">
                        <span class="payment-due__currency">CAD</span>
                        <span
                          class="payment-due__price"
                          data-checkout-payment-due-target="1456"
                        >$14.56</span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>-->
            <div class="order-summary__sections">
              <table class="product-table">
                <colgroup>
                  <col span="1" style="width: 20%;" />
                  <col span="1" style="width: 50%;" />
                  <col span="1" style="width: 15%;" />
                  <col span="1" style="width: 15%;" />
                </colgroup>
                <tr>
                  <th class="product-table-header">Product</th>
                  <th class="product-table-header">Description</th>
                  <th class="product-table-header">Quantity</th>
                  <th class="product-table-header">Price</th>
                </tr>
                <tr>
                  <td>
                    <img src="../assets/Commerce Site Photos/canvas1.jpg" class="product-thumbnail" />
                  </td>
                  <td>
                    <span class="product-table-text" id="productName">{{ productName }}</span>
                  </td>
                  <td>
                    <span class="product-table-text">1</span>
                  </td>
                  <td>
                    <span class="product-table-text" id="productPrice">${{ productPrice }}</span>
                  </td>
                </tr>
              </table>

              <table class="total-table">
                <colgroup>
                  <col span="1" style="width: 85%;" />
                  <col span="1" style="width: 15%;" />
                </colgroup>
                <tr>
                  <td>
                    <span class="total-table-text">Subtotal</span>
                  </td>
                  <td>
                    <span class="total-table-text">${{ subtotal }}</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <span class="total-table-text">Shipping</span>
                  </td>
                  <td>
                    <span class="total-table-text">${{ shippingRate }}</span>
                  </td>
                </tr>
                <tr>
                  <td>
                    <span class="total-table-text">Total</span>
                  </td>
                  <td>
                    <span class="total-table-text" id="total-value">${{ total }}</span>
                  </td>
                </tr>
              </table>
            </div>
          </div>

          <button
            type="button"
            class="btn purchase-button"
            @click="moveToPurchase"
          >Continue to Purchase</button>
        </div>
      </div>
    </main>
    <hr class="hr--large" />
  </main>
</template>

<script>
export default {
  name: "checkout",
  data() {
    return {
      productName: "",
      productPrice: "",
      subtotal: 0.0,
      shippingRate: 10.0,
      total: 0.0
    };
  },
  methods: {
    moveToPurchase() {
      this.$router.push({ name: "purchase" });
    }
  },
  mounted() {
    if (localStorage.productName && localStorage.productPrice) {
      //console.log(localStorage.product);
      this.productName = localStorage.productName;
      this.productPrice = localStorage.productPrice;
    }
    this.subtotal = parseFloat(localStorage.productPrice).toFixed(2);
    this.shippingRate = this.shippingRate.toFixed(2);
    this.total = parseFloat(this.subtotal) + parseFloat(this.shippingRate);
    this.total = this.total.toFixed(2);
  }
};
</script>

<style>
</style>