<template>
  <main id="pageContainer" class="page-container">
    <main class="main-content" role="main">
      <div class="wrapper">
        <div id="shopify-section-collection-template" class="shopify-section">
          <div id="collectionSection">
            <header class="section-header text-center">
              <h1>Canvas Shoes</h1>
              <hr class="hr--small" />
            </header>
            <div class="grid-uniform">
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <router-link
                      class="grid-product__image-link"
                      to="/products/sampleproduct"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </router-link>
                    <!-- <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>-->
                  </div>
                  <router-link to="/products/sampleproduct" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $17.00
                      </span>
                    </span>
                  </router-link>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas2.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </a>
                    <!-- <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>-->
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas3.jpg"
                            class="product--image"
                          />
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__on-sale">
                      <p>
                        Save
                        <br />$1
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third is-sold-out">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas2.jpg"
                            class="product--image"
                          />
                          <!-- <img src="https://dummyimage.com/370x370/000/fff" class="product--image" /> -->
                        </div>
                      </div>
                    </a>
                    <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas3.jpg"
                            class="product--image"
                          />
                          <!-- <img src="https://dummyimage.com/370x370/000/fff" class="product--image" /> -->
                        </div>
                      </div>
                    </a>
                    <!-- <div class="grid-product__sold-out">
                      <p>
                        Sold
                        <br />Out
                      </p>
                    </div>-->
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <div class="grid__item grid-product medium--one-half large--one-third">
                <div class="grid-product__wrapper">
                  <div class="grid-product__image-wrapper" style="height: 309px;">
                    <a
                      class="grid-product__image-link"
                      href="/collections/all/products/birthday-candles"
                      data-image-link
                    >
                      <div id="ProductImageWrapper-23152608962" class="product--wrapper">
                        <div style="padding-top:100.0%;">
                          <img
                            src="../assets/Commerce Site Photos/canvas1.jpg"
                            class="product--image"
                          />
                          <!-- <img src="https://dummyimage.com/370x370/000/fff" class="product--image" /> -->
                        </div>
                      </div>
                    </a>
                    <!-- <div class="grid-product__on-sale">
                      <p>
                        Save
                        <br />$1
                      </p>
                    </div>-->
                  </div>
                  <a href="/collections/all/products/birthday-candles" class="grid-product__meta">
                    <span class="grid-product__title">Lorem, ipsum.</span>
                    <span class="grid-product__price-wrap">
                      <span class="long-dash">—</span>
                      <span class="grid-product__price">
                        <span class="visually-hidden">Regular price</span>
                        $9.50
                      </span>
                    </span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <hr class="hr--large" />
  </main>
</template>

<script>
export default {
  name: "productlist"
};
</script>
