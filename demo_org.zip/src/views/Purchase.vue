<template>
  <main id="pageContainer" class="page-container">
    <main class="main-content" role="main">
      <div class="wrapper">
        <div id="shopify-section-collection-template" class="shopify-section">
          <div id="collectionSection">
            <header class="section-header text-center">
              <h1>Purchase</h1>
              <hr class="hr--small" />
            </header>
          </div>
        </div>
        <div class="step">
          <form class="edit_checkout animate-floating-labels">
            <div class="step__sections">
              <div class="section">
                <div class="section__header">
                  <div class="layout-flex">
                    <h2 class="section__title">Contact Information</h2>
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Email"
                      class="field__input"
                      type="email"
                      id="checkout_email"
                    />
                  </div>
                </div>
              </div>
              <div class="section">
                <div class="section__header">
                  <div class="layout-flex">
                    <h2 class="section__title">Shipping Information</h2>
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input placeholder="Name" class="field__input" type="text" id="checkout_name" />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Address"
                      class="field__input"
                      type="text"
                      id="checkout_address"
                    />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Apartment, Suite, etc. (Optional)"
                      class="field__input"
                      type="text"
                      id="checkout_optional"
                    />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input placeholder="City" class="field__input" type="text" id="checkout_city" />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="State"
                      class="field__input field-one-third"
                      type="text"
                      id="checkout_state"
                    />
                    <input
                      placeholder="Country"
                      class="field__input field-one-third"
                      type="text"
                      id="checkout_country"
                    />
                    <input
                      placeholder="PIN Code"
                      class="field__input field-one-third"
                      type="text"
                      id="checkout_pin"
                    />
                  </div>
                </div>
              </div>
              <div class="section">
                <div class="section__header">
                  <div class="layout-flex">
                    <h2 class="section__title">Payment</h2>
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Card Number"
                      class="field__input"
                      type="text"
                      id="checkout_name"
                    />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Name on Card"
                      class="field__input"
                      type="text"
                      id="checkout_name"
                    />
                  </div>
                </div>
                <div class="section__content">
                  <div class="field">
                    <input
                      placeholder="Expiration Date"
                      class="field__input field--half"
                      type="text"
                      id="checkout_expirydate"
                    />
                    <input
                      placeholder="Security Code"
                      class="field__input field--half"
                      type="text"
                      id="checkout_cvv"
                    />
                  </div>
                </div>
              </div>
            </div>
            <button type="button" class="btn purchase-button">Pay Now</button>
          </form>
        </div>
      </div>
    </main>
  </main>
</template>

<script>
export default {
  name: "purchase"
};
</script>
